-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 21, 2024 at 09:17 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `personal_expense`
--

-- --------------------------------------------------------

--
-- Table structure for table `pe_category`
--

CREATE TABLE `pe_category` (
  `id` int(11) NOT NULL,
  `category` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pe_category`
--

INSERT INTO `pe_category` (`id`, `category`) VALUES
(1, 'Dress'),
(2, 'Rent'),
(3, 'Vehicle'),
(4, 'Food'),
(5, 'Function'),
(6, 'Fancy'),
(7, 'Recharge'),
(8, 'School'),
(9, 'College'),
(10, 'Travel'),
(11, 'EB'),
(12, 'EMI'),
(13, 'Electronics'),
(14, 'Mobile Phone');

-- --------------------------------------------------------

--
-- Table structure for table `pe_expense`
--

CREATE TABLE `pe_expense` (
  `id` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `category` varchar(30) NOT NULL,
  `details` varchar(100) NOT NULL,
  `amount` double NOT NULL,
  `warrenty` varchar(100) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `expense_date` varchar(20) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pe_expense`
--

INSERT INTO `pe_expense` (`id`, `uname`, `category`, `details`, `amount`, `warrenty`, `filename`, `expense_date`, `month`, `year`) VALUES
(1, 'sivam', 'Dress', 'Saree', 500, '', '', '21-05-2024', 5, 2024),
(2, 'sivam', 'Rent', 'Rent', 5000, '', '', '21-05-2024', 5, 2024),
(3, 'sivam', 'Food', 'Veg & Fruits', 1500, '', '', '21-05-2024', 5, 2024),
(4, 'sivam', 'Travel', 'Going to  Temple', 3000, '', '', '20-05-2024', 5, 2024);

-- --------------------------------------------------------

--
-- Table structure for table `pe_income`
--

CREATE TABLE `pe_income` (
  `id` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pe_income`
--

INSERT INTO `pe_income` (`id`, `uname`, `month`, `year`, `amount`) VALUES
(1, 'sivam', 5, 2024, 40000);

-- --------------------------------------------------------

--
-- Table structure for table `pe_login`
--

CREATE TABLE `pe_login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pe_login`
--

INSERT INTO `pe_login` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `pe_suggestion`
--

CREATE TABLE `pe_suggestion` (
  `id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `suggestion` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pe_suggestion`
--

INSERT INTO `pe_suggestion` (`id`, `amount`, `suggestion`) VALUES
(1, 30000, 'Buy Gold'),
(2, 50000, 'Shop business');

-- --------------------------------------------------------

--
-- Table structure for table `pe_user`
--

CREATE TABLE `pe_user` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pe_user`
--

INSERT INTO `pe_user` (`id`, `name`, `address`, `city`, `mobile`, `email`, `uname`, `pass`, `status`, `create_date`) VALUES
(1, 'Sivam', '55, 7th Cross, NG Nagar', 'Salem', 8896544237, 'sivam@gmail.com', 'sivam', '123456', 1, '06-02-2023');
