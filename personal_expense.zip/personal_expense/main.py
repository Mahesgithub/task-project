from flask import Flask
from flask import Flask, render_template, Response, redirect, request, session, abort, url_for
import os
import base64
from PIL import Image
from datetime import datetime
from datetime import date
import datetime
import random
from random import seed
from random import randint
from werkzeug.utils import secure_filename
from flask import send_file
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import threading
import time
import shutil
import hashlib
import urllib.request
import urllib.parse
from urllib.request import urlopen
import webbrowser

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="",
  charset="utf8",
  database="personal_expense"
)


app = Flask(__name__)
##session key
app.secret_key = 'abcdef'
UPLOAD_FOLDER = 'static/upload'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
#####

@app.route('/',methods=['POST','GET'])
def index():
    cnt=0
    act=""
    msg=""

    
    if request.method == 'POST':
        username1 = request.form['uname']
        password1 = request.form['pass']
        mycursor = mydb.cursor()
        mycursor.execute("SELECT count(*) FROM pe_user where uname=%s && pass=%s",(username1,password1))
        myresult = mycursor.fetchone()[0]
        print(myresult)
        if myresult>0:
            session['username'] = username1
            ff=open("user.txt",'w')
            ff.write(username1)
            ff.close()
            result=" Your Logged in sucessfully**"
            return redirect(url_for('userhome')) 
        else:
            msg="Invalid Username or Password!"
            result="You are logged in fail! or not approved!"
        

    return render_template('index.html',msg=msg,act=act)

@app.route('/forgot',methods=['POST','GET'])
def forgot():
    cnt=0
    act=""
    msg=""
    st=""
    email=""
    mess=""
    if request.method == 'POST':
        
        email = request.form['email']
        
        mycursor = mydb.cursor()
        mycursor.execute("SELECT count(*) FROM pe_user where email=%s",(email,))
        cnt = mycursor.fetchone()[0]

        if cnt>0:
            st="1"
            mycursor.execute("SELECT * FROM pe_user where email=%s",(email,))
            myresult = mycursor.fetchone()
            name=myresult[1]
            email=myresult[5]
            uname=myresult[6]
            pw=myresult[7]

            mess="Dear "+name+", Username:"+uname+", Password:"+pw
        else:
            st="2"
        

    return render_template('forgot.html',msg=msg,act=act,st=st,email=email,mess=mess)

@app.route('/login',methods=['POST','GET'])
def login():
    cnt=0
    act=""
    msg=""
    if request.method == 'POST':
        
        username1 = request.form['uname']
        password1 = request.form['pass']
        mycursor = mydb.cursor()
        mycursor.execute("SELECT count(*) FROM pe_login where username=%s && password=%s",(username1,password1))
        myresult = mycursor.fetchone()[0]
        if myresult>0:
            session['username'] = username1
            #result=" Your Logged in sucessfully**"
            return redirect(url_for('admin')) 
        else:
            msg="You are logged in fail!!!"
        

    return render_template('login.html',msg=msg,act=act)


@app.route('/register', methods=['GET', 'POST'])
def register():
    msg=""
    act=request.args.get("act")
    mycursor = mydb.cursor()
    

    if request.method=='POST':
        name=request.form['name']
        address=request.form['address']
        city=request.form['city']
        mobile=request.form['mobile']
        email=request.form['email']
        uname=request.form['uname']
        pass1=request.form['pass']

        

        mycursor.execute("SELECT count(*) FROM pe_user where uname=%s or email=%s",(uname,email))
        myresult = mycursor.fetchone()[0]

        if myresult==0:
        
            mycursor.execute("SELECT max(id)+1 FROM pe_user")
            maxid = mycursor.fetchone()[0]
            if maxid is None:
                maxid=1
            
            now = date.today() #datetime.datetime.now()
            rdate=now.strftime("%d-%m-%Y")
            
            sql = "INSERT INTO pe_user(id,name,address,city,mobile,email,uname,pass,status,create_date) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            val = (maxid,name,address,city,mobile,email,uname,pass1,'0',rdate)
            mycursor.execute(sql, val)
            mydb.commit()

            
            print(mycursor.rowcount, "Registered Success")
            msg="success"
            
            #if cursor.rowcount==1:
            #    return redirect(url_for('index',act='1'))
        else:
            
            msg='fail'
            
    
    return render_template('register.html', msg=msg)

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    msg=""
    act=request.args.get("act")
    email=""
    mess=""
    mycursor = mydb.cursor()
    
    mycursor.execute("SELECT * FROM pe_user")
    data = mycursor.fetchall()

    if act=="yes":
        did=request.args.get("did")
        mycursor.execute("update pe_user set status=1 where id=%s",(did,))
        mydb.commit()
        return redirect(url_for('admin'))
    
    
    return render_template('admin.html',msg=msg,act=act,data=data)

@app.route('/add_cat', methods=['GET', 'POST'])
def add_cat():
    msg=""
    act=request.args.get("act")
    email=""
    mess=""
    mycursor = mydb.cursor()
    
    mycursor.execute("SELECT * FROM pe_category")
    data = mycursor.fetchall()

    if request.method=='POST':
        category=request.form['category']

        mycursor.execute("SELECT count(*) FROM pe_category where category=%s",(category,))
        myresult = mycursor.fetchone()[0]

        if myresult==0:
        
            mycursor.execute("SELECT max(id)+1 FROM pe_category")
            maxid = mycursor.fetchone()[0]
            if maxid is None:
                maxid=1
            
            now = date.today() #datetime.datetime.now()
            rdate=now.strftime("%d-%m-%Y")
            
            sql = "INSERT INTO pe_category(id,category) VALUES (%s,%s)"
            val = (maxid,category)
            mycursor.execute(sql, val)
            mydb.commit()

            
            print(mycursor.rowcount, "Registered Success")
            msg="success"
            
            #if cursor.rowcount==1:
            #    return redirect(url_for('index',act='1'))
        else:
            
            msg='fail'
        
    if act=="del":
        did=request.args.get("did")
        mycursor.execute("delete from pe_category where id=%s",(did,))
        mydb.commit()
        return redirect(url_for('add_cat'))
    
    return render_template('add_cat.html',msg=msg,act=act,data=data)

@app.route('/add_msg', methods=['GET', 'POST'])
def add_msg():
    msg=""
    act=request.args.get("act")
    email=""
    mess=""
    mycursor = mydb.cursor()
    
    mycursor.execute("SELECT * FROM pe_suggestion")
    data = mycursor.fetchall()

    if request.method=='POST':
        amount=request.form['amount']
        suggestion=request.form['suggestion']
     
        mycursor.execute("SELECT max(id)+1 FROM pe_suggestion")
        maxid = mycursor.fetchone()[0]
        if maxid is None:
            maxid=1
        
        sql = "INSERT INTO pe_suggestion(id,amount,suggestion) VALUES (%s,%s,%s)"
        val = (maxid,amount,suggestion)
        mycursor.execute(sql, val)
        mydb.commit()

        
        print(mycursor.rowcount, "Registered Success")
        msg="success"
         
        
    if act=="del":
        did=request.args.get("did")
        mycursor.execute("delete from pe_suggestion where id=%s",(did,))
        mydb.commit()
        return redirect(url_for('add_msg'))
    
    return render_template('add_msg.html',msg=msg,act=act,data=data)


@app.route('/userhome', methods=['GET', 'POST'])
def userhome():
    msg=""
    act=""
    uname=""
    get_qry=""
    ss=""
    data2=[]
    tot=0
    df1=[]
    df2=[]
    if 'username' in session:
        uname = session['username']

    print(uname)
    now = date.today() #datetime.datetime.now()
    rdate=now.strftime("%d-%m-%Y")
            
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM pe_user where uname=%s",(uname, ))
    data = mycursor.fetchone()

    mycursor.execute("SELECT * FROM pe_category")
    data1 = mycursor.fetchall()

    mon=now.strftime("%m")
    yr=now.strftime("%Y")

    if request.method=='POST':
        
        category=request.form['category']
        get_qry=request.form['get_qry']
        ss="1"
        q=""

        
        #ed=edate.split('-')
        #edd=ed[2]+"-"+ed[1]+"-"+ed[0]

        eamt=0
        if get_qry=="" and category=="":
            mycursor.execute("SELECT * FROM pe_expense where uname=%s && expense_date=%s order by id desc",(uname,rdate))
        else:
            if get_qry=="":
                mycursor.execute("SELECT * FROM pe_expense where uname=%s && category=%s order by id desc",(uname,category))
            elif category=="":
                det='%'+get_qry+'%'
                mycursor.execute("SELECT * FROM pe_expense where uname=%s && details like %s order by id desc",(uname,det))
            else:
                det='%'+get_qry+'%'
                mycursor.execute("SELECT * FROM pe_expense where uname=%s && category=%s && details like %s order by id desc",(uname,category,det))
            
            
        data2 = mycursor.fetchall()

        for dd in data2:
            eamt+=dd[4]

        ####
        
        
        mycursor.execute("SELECT sum(amount),month FROM pe_expense where uname=%s && year=%s group by month",(uname,yr))
        dat1 = mycursor.fetchall()
        dt1=[]
        dt2=[]
        marr=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
        for d1 in dat1:
            m=d1[1]
            m1=m-1
            dt1.append(marr[m1])

            dt2.append(d1[0])
        ##########
        #pie--appliances
        bval=dt1
         
        gdata = dt2
         
        # Creating plot
        fig = plt.figure(figsize =(10, 7))
        plt.pie(gdata, labels = bval)
         
        # show plot
        #plt.show()
        fn=uname+"_g1.png"
        plt.savefig('static/graph/'+fn)
        plt.close()
        #############################################
        
        mycursor.execute("SELECT count(*) FROM pe_expense where uname=%s",(uname,))
        df11 = mycursor.fetchone()[0]
        if df11>0:
            mycursor.execute("SELECT category,count(category) FROM pe_expense where uname=%s group by category order by count(category) desc",(uname,))
            df1 = mycursor.fetchall()
            doc=[]
            values=[]
            k=0
            for d1 in df1:
                if k<10:
                    doc.append(d1[0])
                    values.append(d1[1])
                k+=1
                
            t=len(doc)
            #doc = dd1 #list(data.keys())
            #values = dd2 #list(data.values())
              
            fig = plt.figure(figsize = (10, 5))

            ccc=['red','orange','yellow','green','brown','blue','pink','green','yellow','red','pink','blue','yellow']
            c=[]
            j=0
            while j<t:
                n2=randint(0,11)
                ccc1=ccc[n2]
                c.append(ccc1)
                j+=1
            # creating the bar plot
            plt.bar(doc, values, color =c, width = 0.4)

            #plt.ylim((1,g1))

            plt.xlabel("Category")
            plt.ylabel("Expese")
            plt.title("")
            
            fn=uname+"_g3.png"
            plt.savefig('static/graph/'+fn)
            plt.close()    
            ##
        ###################################
    
        if df11>0:
            mycursor.execute("SELECT category,sum(amount) FROM pe_expense where uname=%s group by category order by sum(amount) desc",(uname,))
            df2 = mycursor.fetchall()
            doc=[]
            values=[]
            k=0
            for d2 in df2:
                if k<10:
                    doc.append(d2[0])
                    values.append(d2[1])
                k+=1
                
            t=len(doc)
            #doc = dd1 #list(data.keys())
            #values = dd2 #list(data.values())
              
            fig = plt.figure(figsize = (10, 5))

            ccc=['red','orange','yellow','green','brown','blue','pink','green','yellow','red','pink','blue','yellow']
            c=[]
            j=0
            while j<t:
                n2=randint(0,11)
                ccc1=ccc[n2]
                c.append(ccc1)
                j+=1
            # creating the bar plot
            plt.bar(doc, values, color =c, width = 0.4)

            #plt.ylim((1,g1))

            plt.xlabel("Category")
            plt.ylabel("Expese")
            plt.title("")
            
            fn=uname+"_g4.png"
            plt.savefig('static/graph/'+fn)
            plt.close()    
            ##
        ###################################
            
    if ss=="":
        mycursor.execute("SELECT * FROM pe_expense where uname=%s && expense_date=%s order by id desc",(uname,rdate))
        data2 = mycursor.fetchall()
        eamt=0
        for dd in data2:
            eamt+=dd[4]

    tot=eamt
    
    if act=="del":
        did=request.args.get("did")
        mycursor.execute("delete from pe_expense where id=%s && uname=%s",(did,uname))
        mydb.commit()
        return redirect(url_for('userhome'))

    
    
    return render_template('userhome.html',msg=msg,act=act,data=data,data1=data1,data2=data2,get_qry=get_qry,ss=ss,tot=tot,yr=yr,df1=df1,df2=df2)

@app.route('/add_expense', methods=['GET', 'POST'])
def add_expense():
    msg=""
    act=request.args.get("act")
    email=""
    mess=""
    uname=""
    file_name=""
    if 'username' in session:
        uname = session['username']
        
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM pe_user where uname=%s",(uname, ))
    data = mycursor.fetchone()
    
    mycursor.execute("SELECT * FROM pe_category")
    data1 = mycursor.fetchall()

    mycursor.execute("SELECT * FROM pe_expense where uname=%s order by id desc",(uname,))
    data2 = mycursor.fetchall()

    now = date.today() #datetime.datetime.now()
    rdate=now.strftime("%Y-%m-%d")

    if request.method=='POST':
        expense_date=request.form['expense_date']
        category=request.form['category']
        details=request.form['details']
        amount=request.form['amount']
        warrenty=request.form['warrenty']

        file= request.files['file']
        
        mycursor.execute("SELECT max(id)+1 FROM pe_expense")
        maxid = mycursor.fetchone()[0]
        if maxid is None:
            maxid=1

        if file:
            fname1 = file.filename
            fname = secure_filename(fname1)
            file_name="P"+str(maxid)+fname
            file.save(os.path.join("static/upload/", file_name))


        ex=expense_date.split("-")
        month=ex[1]
        year=ex[0]
        ex_date=ex[2]+"-"+ex[1]+"-"+ex[0]
        
        sql = "INSERT INTO pe_expense(id,uname,category,details,amount,warrenty,filename,expense_date,month,year) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        val = (maxid,uname,category,details,amount,warrenty,file_name,ex_date,month,year)
        mycursor.execute(sql, val)
        mydb.commit()

        
        print(mycursor.rowcount, "Registered Success")
        msg="success"

        
    if act=="del":
        did=request.args.get("did")
        mycursor.execute("delete from pe_expense where id=%s && uname=%s",(did,uname))
        mydb.commit()
        return redirect(url_for('add_expense'))
    
    return render_template('add_expense.html',msg=msg,act=act,data=data,data1=data1,data2=data2,rdate=rdate)

@app.route('/add_income', methods=['GET', 'POST'])
def add_income():
    msg=""
    act=request.args.get("act")
    email=""
    mess=""
    uname=""
    file_name=""
    if 'username' in session:
        uname = session['username']
        
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM pe_user where uname=%s",(uname, ))
    data = mycursor.fetchone()
    
    mycursor.execute("SELECT * FROM pe_category")
    data1 = mycursor.fetchall()

    mycursor.execute("SELECT * FROM pe_income where uname=%s order by id desc",(uname,))
    data2 = mycursor.fetchall()

    now = date.today() #datetime.datetime.now()
    rdate=now.strftime("%Y-%m-%d")

    if request.method=='POST':
        month=request.form['month']
        year=request.form['year']
        
        amount=request.form['amount']

        mycursor.execute("SELECT count(*) FROM pe_income where uname=%s && month=%s && year=%s",(uname,month,year))
        cnt = mycursor.fetchone()[0]
        if cnt==0:
            mycursor.execute("SELECT max(id)+1 FROM pe_income")
            maxid = mycursor.fetchone()[0]
            if maxid is None:
                maxid=1

            sql = "INSERT INTO pe_income(id,uname,month,year,amount) VALUES (%s,%s,%s,%s,%s)"
            val = (maxid,uname,month,year,amount)
            mycursor.execute(sql, val)
            mydb.commit()
        else:
            mycursor.execute("update pe_income set amount=%s where uname=%s && month=%s && year=%s",(amount,uname,month,year))
            mydb.commit()
        
        
        msg="success"

        
    if act=="del":
        did=request.args.get("did")
        mycursor.execute("delete from pe_income where id=%s",(did,))
        mydb.commit()
        return redirect(url_for('add_income'))
    
    return render_template('add_income.html',msg=msg,act=act,data=data,data1=data1,data2=data2,rdate=rdate)

@app.route('/user_daily', methods=['GET', 'POST'])
def user_daily():
    msg=""
    act=""
    uname=""
    get_qry=""
    ss=""
    data2=[]
    tot=0
    if 'username' in session:
        uname = session['username']

    print(uname)
    now = date.today() #datetime.datetime.now()
    rdate=now.strftime("%d-%m-%Y")
            
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM pe_user where uname=%s",(uname, ))
    data = mycursor.fetchone()

    mycursor.execute("SELECT * FROM pe_category")
    data1 = mycursor.fetchall()


    if request.method=='POST':
        
        edate=request.form['edate']
        
        ss="1"
        q=""

        
        ed=edate.split('-')
        edd=ed[2]+"-"+ed[1]+"-"+ed[0]

        eamt=0
        mycursor.execute("SELECT * FROM pe_expense where uname=%s && expense_date=%s order by id desc",(uname,edd))
        data2 = mycursor.fetchall()

        for dd in data2:
            eamt+=dd[4]
            
    if ss=="":
        mycursor.execute("SELECT * FROM pe_expense where uname=%s && expense_date=%s order by id desc",(uname,rdate))
        data2 = mycursor.fetchall()
        eamt=0
        for dd in data2:
            eamt+=dd[4]

    tot=eamt
    
    if act=="del":
        did=request.args.get("did")
        mycursor.execute("delete from pe_expense where id=%s && uname=%s",(did,uname))
        mydb.commit()
        return redirect(url_for('user_daily'))

    ####
    mon=now.strftime("%m")
    yr=now.strftime("%Y")
    
    mycursor.execute("SELECT sum(amount),month FROM pe_expense where uname=%s && year=%s group by month",(uname,yr))
    dat1 = mycursor.fetchall()
    dt1=[]
    dt2=[]
    marr=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    for d1 in dat1:
        m=d1[1]
        m1=m-1
        dt1.append(marr[m1])

        dt2.append(d1[0])
    ##########
    #pie--appliances
    bval=dt1
     
    gdata = dt2
     
    # Creating plot
    '''fig = plt.figure(figsize =(10, 7))
    plt.pie(gdata, labels = bval)
     
    # show plot
    #plt.show()
    fn=uname+"_g1.png"
    plt.savefig('static/graph/'+fn)
    plt.close()'''
    #############################################
    
    
    return render_template('user_daily.html',msg=msg,act=act,data=data,data1=data1,data2=data2,get_qry=get_qry,ss=ss,tot=tot,yr=yr)

def unique(list1):
 
    # initialize a null list
    unique_list = []
 
    # traverse for all elements
    for x in list1:
        # check if exists in unique_list or not
        if x not in unique_list:
            unique_list.append(x)
    return unique_list
            
@app.route('/user_monthly', methods=['GET', 'POST'])
def user_monthly():
    msg=""
    act=""
    uname=""
    get_qry=""
    ss=""
    data2=[]
    tot=0
    mon1=""
    mon2=""
    yr1=""
    s1=""

    totin=0
    totexp=0
    bal=0
    savings=0
    sn=""
    sgdata=[]
    
    if 'username' in session:
        uname = session['username']

    marr=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    
    #uname="sivam"
    now = date.today() #datetime.datetime.now()
    rdate=now.strftime("%d-%m-%Y")
    cmon=now.strftime("%m")
    cyr=now.strftime("%Y")
            
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM pe_user where uname=%s",(uname, ))
    data = mycursor.fetchone()

    mycursor.execute("SELECT * FROM pe_category")
    data1 = mycursor.fetchall()

    mycursor.execute("SELECT distinct(month) FROM pe_expense where uname=%s order by month",(uname, ))
    data3 = mycursor.fetchall()

    mycursor.execute("SELECT distinct(year) FROM pe_expense where uname=%s order by year desc",(uname, ))
    data4 = mycursor.fetchall()


    if request.method=='POST':
        s1="1"
        month=request.form['month']
        year=request.form['year']
        
        ss="1"
        q=""

        mon1=month
        yr1=year
        eamt=0
        '''if month=="" and year=="":
            mycursor.execute("SELECT * FROM pe_expense where uname=%s && month=%s && year=%s order by id desc",(uname,cmon,cyr))
        elif month=="":
            mycursor.execute("SELECT * FROM pe_expense where uname=%s && year=%s order by id desc",(uname,year))
        elif year=="":
            mycursor.execute("SELECT * FROM pe_expense where uname=%s && month=%s order by id desc",(uname,month))
        else:
            mycursor.execute("SELECT * FROM pe_expense where uname=%s && month=%s && year=%s order by id desc",(uname,month,year))'''
            
        mycursor.execute("SELECT * FROM pe_expense where uname=%s && month=%s && year=%s order by id desc",(uname,month,year))
        data2 = mycursor.fetchall()
        eamt=0
        mon1=cmon
        yr1=cyr
        for dd in data2:
            eamt+=dd[4]
        tot=eamt
        #for dd in data2:
        #    eamt+=dd[4]

        ###
        '''if month=="" and year=="":
            mycursor.execute("SELECT sum(amount) FROM pe_income where uname=%s && month=%s && year=%s order by id desc",(uname,cmon,cyr))
            totin = mycursor.fetchone()[0]
            
            mycursor.execute("SELECT sum(amount) FROM pe_expense where uname=%s && month=%s && year=%s order by id desc",(uname,cmon,cyr))
            totexp = mycursor.fetchone()[0]

            bal=totin-totexp'''
        ###
            
    '''if ss=="":
        mycursor.execute("SELECT * FROM pe_expense where uname=%s && month=%s && year=%s order by id desc",(uname,cmon,cyr))
        data2 = mycursor.fetchall()
        eamt=0
        mon1=cmon
        yr1=cyr
        for dd in data2:
            eamt+=dd[4]'''

    #tot=eamt
    
    
    if act=="del":
        did=request.args.get("did")
        mycursor.execute("delete from pe_expense where id=%s && uname=%s",(did,uname))
        mydb.commit()
        return redirect(url_for('user_monthly'))

    #######
    mon=now.strftime("%m")
    yr=now.strftime("%Y")
    
    '''mycursor.execute("SELECT sum(amount),month FROM pe_expense where uname=%s && year=%s group by month",(uname,yr))
    dat1 = mycursor.fetchall()
    dt1=[]
    dt2=[]
    
    for d1 in dat1:
        m=d1[1]
        m1=m-1
        dt1.append(marr[m1])

        dt2.append(d1[0])
    ##########
    #pie--appliances
    bval=dt1
     
    gdata = dt2'''
     
    # Creating plot
    '''fig = plt.figure(figsize =(10, 7))
    plt.pie(gdata, labels = bval)
     
    # show plot
    #plt.show()
    fn=uname+"_g1.png"
    #plt.savefig('static/graph/'+fn)
    plt.close()'''
    ########################
    
    '''doc=[]
    values=[]
    ct=[]
    for df1 in data2:
        #print(df1[2])
        ct.append(df1[2])
    
    ##unique cat
    ctry=unique(ct)

   
    ln=len(ctry)
    
    if ln>0:
        for cty in ctry:
            if mon1=="" and yr1=="":
                mycursor.execute("SELECT sum(amount),category FROM pe_expense where uname=%s && category=%s && month=%s && year=%s group by category order by sum(amount) desc",(uname,cty,cmon,cyr))

            elif mon1=="":
                mycursor.execute("SELECT sum(amount),category FROM pe_expense where uname=%s && category=%s && year=%s group by category order by sum(amount) desc",(uname,cty,yr1))

            elif yr1=="":
                mycursor.execute("SELECT sum(amount),category FROM pe_expense where uname=%s && category=%s && month=%s group by category order by sum(amount) desc",(uname,cty,mon1))

            else:
                mycursor.execute("SELECT sum(amount),category FROM pe_expense where uname=%s && category=%s && month=%s && year=%s group by category order by sum(amount) desc",(uname,cty,mon1,yr1))
                
            
            dat3 = mycursor.fetchone()
            values.append(dat3[0])
            doc.append(dat3[1])
            
    t=ln'''
    ##########
    #doc=[]
    #values=[]
    #doc = dd1 #list(data.keys())
    #values = dd2 #list(data.values())
      
    '''fig = plt.figure(figsize = (10, 5))

    ccc=['red','orange','yellow','green','brown','blue','pink','green','yellow','red','pink','blue','yellow']
    c=[]
    j=0
    while j<t:
        n2=randint(0,11)
        ccc1=ccc[n2]
        c.append(ccc1)
        j+=1
    # creating the bar plot
    plt.bar(doc, values, color =c, width = 0.4)

    #plt.ylim((1,g1))

    plt.xlabel("Category")
    plt.ylabel("Expense")
    plt.title("")
    
    fn=uname+"_g2.png"
    plt.savefig('static/graph/'+fn)
    plt.close() '''   


    ########
    if mon1=="":
        s=""
    else:
        mn=int(mon1)-1
        mon2=marr[mn]
    ##Savings#############################
    totin2=0
    totexp2=0
    mycursor.execute("SELECT * FROM pe_income where uname=%s",(uname,))
    t1 = mycursor.fetchall()
    for t2 in t1:
        totin2+=t2[4]
    
    mycursor.execute("SELECT * FROM pe_expense where uname=%s",(uname,))
    e1 = mycursor.fetchall()
    for e2 in e1:
        totexp2+=e2[4]

    savings=int(totin2)-int(totexp2)

    if savings>=1000:
        a1=savings
        a2=savings+5000
        mycursor.execute("SELECT count(*) FROM pe_suggestion where amount between %s and %s",(a1,a2))
        snt = mycursor.fetchone()[0]
        if snt>0:
            sn="1"
            mycursor.execute("SELECT * FROM pe_suggestion where amount between %s and %s",(a1,a2))
            sgdata = mycursor.fetchall()
    
    
    return render_template('user_monthly.html',msg=msg,act=act,data=data,data1=data1,data2=data2,data3=data3,data4=data4,ss=ss,s1=s1,tot=tot,yr=yr,mon2=mon2,yr1=yr1,totin=totin,totexp=totexp,bal=bal,savings=savings,sn=sn,sgdata=sgdata)


@app.route('/logout')
def logout():
    # remove the username from the session if it is there
    session.pop('username', None)
    return redirect(url_for('index'))


if __name__ == "__main__":
    app.secret_key = os.urandom(12)
    app.run(debug=True,host='0.0.0.0', port=5000)
